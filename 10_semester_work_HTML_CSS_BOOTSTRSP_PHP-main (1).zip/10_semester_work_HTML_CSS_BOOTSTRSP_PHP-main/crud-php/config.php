<?php

$databaseHost = 'localhost';
$databaseName = 'crud-php';
$databaseUsername = 'root';
$databasePassword = '';
$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
